
<?php # DISPLAY COMPLETE LOGIN PAGE.

# Set page title and display header section.
$page_title = 'Login' ;
include ( 'NavBar_notLoggedIn.html' ) ;

# Display any error messages if present.
if ( isset( $errors ) && !empty( $errors ) )
{
 echo '<p id="err_msg">Oops! There was a problem:<br>' ;
 foreach ( $errors as $msg ) { echo " - $msg<br>" ; }
 echo 'Please try again or create account.</p>' ;
}
?>



<!-- Display body section. -->

<div class="container">
	<p class="lead"><i class="fa fa-user"></i>  Login</p>
</div>
                
	<div class="container">
        <div class="row">
			<div class="col">
				<form action="login_action.php" method="post">
				
				<div class="form-group">
					<label for="email">Email</label>
						<div class="row">
							<div class="col">
								<input type="text" class="form-control" placeholder="Email" name="email">
							</div>
						</div>
				</div>
					
				<div class="form-group">
					<label for="password">Password: </label>
						<div class="row">
							<div class="col">
								<input type="password" class="form-control" placeholder="Password" name="pass">
							</div>
						</div>
				</div>
						
				<div class="form-group">
					<br>
						<div class="row">
							<div class="col">
								<input class="btn btn-dark btn-lg btn-block" type="submit" value="Login Now">
							</div>
						</div>
				</div>
				
			
				</form>


				
				<form method="get" action="register.php">
				<div class="form-group">
					
						<div class="row">
							<div class="col">
								<input class="btn btn-dark btn-lg btn-block" type="submit" value="Create Account">
							</div>
						</div>
				</div>
	</div>
				
				</form>


  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>

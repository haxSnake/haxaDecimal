<?php
  require_once("php/connect_ldb.php");

  if(!isset($_SESSION)){
    session_start();
  }

  if(isset($_SESSION["admin_name"])!=""){
    header("Location: index.php");
  }
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Material Design Lite</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="images/android-desktop.png">

    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <link rel="shortcut icon" href="images/favicon.png">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body class="login-bg">
    <div>
  <?php
    if(!isset($_POST["submit"])){
  ?>
      <div class="mdl-card mdl-shadow-2dp login-card-wide">
        <div class="account-info mdl-color--primary">
          <span>Admin Register</span>
          </br>
        </div>

        <div class="account-data">
          <form class="form-signin" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
              <input class="mdl-textfield__input" type="text" id="username" name="username">
              <label class="mdl-textfield__label" for="username">Admin Name</label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
              <input class="mdl-textfield__input" type="text" id="email" name="email">
              <label class="mdl-textfield__label" for="email">Email</label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
              <input class="mdl-textfield__input" type="password" id="password" name="password">
              <label class="mdl-textfield__label" for="password">Password</label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
              <input class="mdl-textfield__input" type="password" id="confirm_password" name="confirm_password">
              <label class="mdl-textfield__label" for="confirm_password">Confirm Password</label>

            </div>
			<label class="form-check-label" for="exampleCheck1">Check me out</label>
		     <div class="row">
				<div class="col">
                <input type="checkbox" name="test" class="form-check-input" id="exampleCheck1" value="<?php if (isset($_POST['checkbox']))
					echo $_POST['checkbox'] ?>">

				<p><span class="badge badge-light">Subscribe</span></p>
			</div>

            <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--primary right" type="submit" name="submit">Register</button>
          </form>
        </div>
      </div>
    </div>
  <?php
	} else {
		// Prepare data to insert into the DB
		$admin_name	= $_POST['user_name'];
		$email		= $_POST['email'];
		$password	= $_POST['password'];
		$confirm_password = $_POST['confirm_password'];

		if (isset($_POST['checkbox'])) {
    $s = 1;
  } else{
    $s = 0;
  }
		if($password == $confirm_password){


		} else {
			echo "<script language=\"JavaScript\">\n";
			echo "alert('Password confirm failed!');\n";
			echo "window.location='register.php'";
			echo "</script>";
			exit();

		}

		// Checks if Username and Email exists. If not insert into the DB
		$exists = 0;

		// DB Queries
		$check_admin_name = "SELECT username from user WHERE admin_name = '$un' LIMIT 1";
		$check_admin_email = "SELECT email from user WHERE email = '$email' LIMIT 1";

		// Run DB Queries
		$run_check_admin_name_query = mysqli_query($con, $check_admin_name);
		$run_check_admin_email_query = mysqli_query($con, $check_admin_email);

		// Checks the number of rows(entries) on the DB for Username and Email
		$num_row_admin = mysqli_num_rows($run_check_admin_name_query);
		$num_row_email = mysqli_num_rows($run_check_admin_email_query);

		$result = $num_row_admin;

		if ($result == 1) {
			$exists = 1;
			$result = $num_row_email;
			if ($result == 1) $exists = 2;
		} else {
			$result = $num_row_email;
			if ($result == 1) $exists = 3;
		}

		if ($exists == 1){
			echo "<script language=\"JavaScript\">\n";
			echo "alert('Admin Name already exists!');\n";
			echo "window.location='register.php'";
			echo "</script>";
			exit();

		} else if ($exists == 2){
			echo "<script language=\"JavaScript\">\n";
			echo "alert('Admin Name and Email already exists!');\n";
			echo "window.location='register.php'";
			echo "</script>";
			exit();

		} else if ($exists == 3){
			echo "<script language=\"JavaScript\">\n";
			echo "alert('Email already exists!');\n";
			echo "window.location='register.php'";
			echo "</script>";
			exit();

		} else {
			// Insert data into DB
			$insert_admin = "INSERT INTO admins(username, password,email, password, subscription)
						VALUES ('$un', '$password, '$email', 'subscription')";

			$insert_admin_query = mysqli_query($con, $insert_admin);

			if ($insert_admin_query) {
				mysqli_close($con);

				echo "<script language=\"JavaScript\">\n";
				echo "alert('Admin Successfully Registered!');\n";

				//Redirect to index.php
				echo "window.location='index.php'";
				echo "</script>";

			} else {
		 		echo "Error Inserting Admin: " . mysqli_connect_errno();
				exit();

			}
		}
	}
  ?>

    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>

<?php # DISPLAY COMPLETE REGISTRATION PAGE.

# Set page title and display header section.
$page_title = 'Register' ;
include ( 'NavBar_notLoggedIn.html' ) ;

# Check form submitted.
if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
{
  # Connect to the database.
  require ('connect_db.php');

  # Initialize an error array.
  $errors = array();

  # Check for a first name.
  if ( empty( $_POST[ 'first_name' ] ) )
  { $errors[] = 'Enter your first name.' ; }
  else
  { $fn = mysqli_real_escape_string( $link, trim( $_POST[ 'first_name' ] ) ) ; }

  # Check for a last name.
  if (empty( $_POST[ 'last_name' ] ) )
  { $errors[] = 'Enter your last name.' ; }
  else
  { $ln = mysqli_real_escape_string( $link, trim( $_POST[ 'last_name' ] ) ) ; }

  # Check for an email address:
  if ( empty( $_POST[ 'email' ] ) )
  { $errors[] = 'Enter your email address.'; }
  else
  { $e = mysqli_real_escape_string( $link, trim( $_POST[ 'email' ] ) ) ; }

  # Check for a password and matching input passwords.
  if ( !empty($_POST[ 'pass1' ] ) )
  {
    if ( $_POST[ 'pass1' ] != $_POST[ 'pass2' ] )
    { $errors[] = 'Passwords do not match.' ; }
    else
    { $p = mysqli_real_escape_string( $link, trim( $_POST[ 'pass1' ] ) ) ; }
  }
  else { $errors[] = 'Enter your password.' ; }

  # Check if email address already registered.
  if ( empty( $errors ) )
  {
    $q = "SELECT user_id FROM users WHERE email='$e'" ;
    $r = @mysqli_query ( $link, $q ) ;
    if ( mysqli_num_rows( $r ) != 0 ) $errors[] = 'Email address already registered. <a href="login.php">Login</a>' ;
  }

  # On success register user inserting into 'users' database table.
  if ( empty( $errors ) )
  {
    $q = "INSERT INTO users (first_name, last_name, email, pass, reg_date) VALUES ('$fn', '$ln', '$e', SHA1('$p'), NOW() )";
    $r = @mysqli_query ( $link, $q ) ;
    if ($r)
    { echo '<h1>Registered!</h1><p>You are now registered.</p><p><a href="login.php">Login</a></p>'; }

    # Close database connection.
    mysqli_close($link);

    # Display footer section and quit script:
    include ('includes/reg_foot.html');
    exit();
  }
  # Or report errors.
  else
  {
    echo '<p id="err_msg">The following error(s) occurred:<br>' ;
    foreach ( $errors as $msg )
    { echo " - $msg<br>" ; }
    echo 'Please try again.</p>';
    # Close database connection.
    mysqli_close( $link );
  }
}
?>

<!-- Display body section with sticky form. -->
<div class="container">
	<p class="lead"><i class="fa fa-user-plus"></i>  Create New Account</p>
	<form action="register.php" method="post">

		<div class="form-group">
		<label for="first_name">First Name</label>
			 <div class="row">
				<div class="col">
				<input type="text" class="form-control" placeholder="First name"name="first_name" size="20" value="<?php if (isset($_POST['first_name'])) echo $_POST['first_name']; ?>">
				</div>
			 </div>
		</div>


		<div class="form-group">
		<label for="last_name">Last Name</label>
				<div class="row">
					<div class="col">
					<input type="text" class="form-control" placeholder="Last name"name="last_name" size="20" value="<?php if (isset($_POST['last_name'])) echo $_POST['last_name']; ?>">
					</div>
				</div>
		</div>

		<div class="form-group">
		<label for="email">Email</label>
			 <div class="row">
				<div class="col">
				<input type="text" class="form-control" placeholder="Email" name="email" size="50" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
				</div>
			 </div>
		</div>

		<div class="form-group">
		<label for="password">Create Password</label>
			 <div class="row">
				<div class="col">
				<input type="password" class="form-control" placeholder="Create Password" name="pass1" size="20" value="<?php if (isset($_POST['pass1'])) echo $_POST['pass1']; ?>" >
			 </div>
		 </div>
		</div>

		<div class="form-group">
		<label for="confirm_password">Confirm Password</label>
			 <div class="row">
				<div class="col">
				<input type="password" class="form-control" placeholder="Confirm Password" name="pass2" size="20" value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>">
				</div>
			 </div>
		</div>

		<div class="form-group">
		<label for="confirm_password">Register Now</label>
			 <div class="row">
				<div class="col">
				<input class="btn btn-dark btn-lg btn-block" type="submit" value="Create Account Now">

				</div>
			 </div>

	</form>

		 </div>

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

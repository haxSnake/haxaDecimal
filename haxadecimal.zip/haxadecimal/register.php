<?php # DISPLAY COMPLETE REGISTRATION PAGE.

# Set page title and display header section.
$page_title = 'Register' ;
# Check form submitted.
if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
{
  # Connect to the database.
  require ('PHP/connect_db.php');

  # Initialize an error array.
  $errors = array();

  # Check for a first name.
  if ( empty( $_POST[ 'user_name' ] ) )
  { $errors[] = 'Enter your username.' ; }
  else
  { $userId = mysqli_real_escape_string( $link, trim( $_POST[ 'user_name' ] ) ) ; }

  if ( empty( $_POST[ 'first_name' ] ) )
  { $errors[] = 'Enter your first name.' ; }
  else
  { $firstName = mysqli_real_escape_string( $link, trim( $_POST[ 'first_name' ] ) ) ; }

  if ( empty( $_POST[ 'last_name' ] ) )
  { $errors[] = 'Enter your last name.' ; }
  else
  { $lastName = mysqli_real_escape_string( $link, trim( $_POST[ 'last_name' ] ) ) ; }

  if ( empty( $_POST[ 'DOB' ] ) )
  { $errors[] = 'Enter your date of birth name.' ; }
  else
  { $dob = mysqli_real_escape_string( $link, trim( $_POST[ 'DOB' ] ) ) ; }

  # Check for a last name.
  if (empty( $_POST[ 'email' ] ) )
  { $errors[] = 'Enter your email.' ; }
  else
  { $email = mysqli_real_escape_string( $link, trim( $_POST[ 'email' ] ) ) ; }

  # Check for a password and matching input passwords.
  if ( !empty($_POST[ 'pass1' ] ) )
  {
    if ( $_POST[ 'pass1' ] != $_POST[ 'pass2' ] )
    { $errors[] = 'Passwords do not match.' ; }
    else
    { $pw = mysqli_real_escape_string( $link, trim( $_POST[ 'pass1' ] ) ) ; }
  }
  else { $errors[] = 'Enter your password.' ; }

  if ( empty( $_POST[ 'address' ] ) )
  { $errors[] = 'Enter your address.' ; }
  else
  { $street = mysqli_real_escape_string( $link, trim( $_POST[ 'address' ] ) ) ; }

  if ( empty( $_POST[ 'postcode' ] ) )
  { $errors[] = 'Enter your postcode.' ; }
  else
  { $postcode = mysqli_real_escape_string( $link, trim( $_POST[ 'postcode' ] ) ) ; }

  if ( empty( $_POST[ 'city' ] ) )
  { $errors[] = 'Enter city.' ; }
  else
  { $city = mysqli_real_escape_string( $link, trim( $_POST[ 'city' ] ) ) ; }

  if ( empty( $_POST[ 'country' ] ) )
  { $errors[] = 'Enter country.' ; }
  else
  { $country = mysqli_real_escape_string( $link, trim( $_POST[ 'country' ] ) ) ; }

  # Check if email address already registered.
  if ( empty( $errors ) )
  {
    $q = "SELECT userId FROM user WHERE email='$email'" ;
    $r = @mysqli_query ( $link, $q ) ;
    if ( mysqli_num_rows( $r ) != 0 ) $errors[] = 'Email address already registered. <a href="login.php">Login</a>' ;
  }

  # On success register user inserting into 'users' database table.
  if ( empty( $errors ) )
  {
    $q = "INSERT INTO user (userId, firstName, lastName, dob, email, pw, street, postcode, city, country) VALUES ('$userId', '$firstName', '$lastName', '$dob', '$email','$pw', '$street', '$postcode', '$city', '$country' )";
    $r = @mysqli_query ( $link, $q ) ;
    if ($r)
    { echo '<h1>Registered!</h1><p>You are now registered.</p><p><a href="login.php">Login</a></p>'; }else{
      echo '<h1>Not registered</h1>';
    }

    # Close database connection.
    mysqli_close($link);

    # Display footer section and quit script:
    exit();
  }
  # Or report errors.
  else
  {
    echo '<p id="err_msg">The following error(s) occurred:<br>' ;
    foreach ( $errors as $msg )
    { echo " - $msg<br>" ; }
    echo 'Please try again.</p>';
    # Close database connection.
    mysqli_close( $link );
  }
?>


<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>User Panel</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>


  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <form action="register.php" method="post">
      <div class="card-body">
          <div class="form-group">
            <label for="user_name">Username</label>
            <input class="form-control" id="user_name" type="user_name" aria-describedby="usernameHelp" placeholder="Enter Username" value="<?php if (isset($_POST['user_name'])) echo $_POST['user_name']; ?>">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="pass1">Password</label>
                <input class="form-control" id="pass1" type="password" placeholder="Password" value="<?php if (isset($_POST['pass1'])) echo $_POST['pass1']; ?>">
              </div>
              <div class="col-md-6">
                <label for="pass2">Confirm password</label>
                <input class="form-control" id="pass2" type="confirm_password" placeholder="Confirm password" value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>">
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="email">Email Address</label>
                <input class="form-control" id="email" type="text" aria-describedby="emailHelp" placeholder="Enter Email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
              </div>
              <div class="col-md-6">
                <label for="DOB">Date Of Birth</label>
                <input class="form-control" id="DOB" type="text" aria-describedby="DOBHelp" placeholder="Enter DOB" value="<?php if (isset($_POST['DOB'])) echo $_POST['DOB']; ?>">
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="first_name">First name</label>
                <input class="form-control" id="first_name" type="text" aria-describedby="firstnameHelp" placeholder="Enter first name" value="<?php if (isset($_POST['first_name'])) echo $_POST['first_name']; ?>">
              </div>
              <div class="col-md-6">
                <label for="last_name">Last name</label>
                <input class="form-control" id="last_name" type="text" aria-describedby="lastnameHelp" placeholder="Enter last name" value="<?php if (isset($_POST['last_name'])) echo $_POST['last_name']; ?>">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input class="form-control" id="address" type="text" aria-describedby="addressHelp" placeholder="Enter address" value="<?php if (isset($_POST['addess'])) echo $_POST['address']; ?>">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="city">City</label>
                <input class="form-control" id="city" type="text" aria-describedby="cityHelp" placeholder="Enter City" value="<?php if (isset($_POST['city'])) echo $_POST['city']; ?>">
              </div>
              <div class="col-md-6">
                <label for="postcode">Postcode</label>
                <input class="form-control" id="postcode" type="text" aria-describedby="postcodeHelp" placeholder="Enter Postcode" value="<?php if (isset($_POST['postcode'])) echo $_POST['postcode']; ?>">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="country">Country</label>
            <input class="form-control" id="country" type="text" aria-describedby="countryHelp" placeholder="Enter Country" value="<?php if (isset($_POST['country'])) echo $_POST['country']; ?>">
          </div>

          <a class="btn btn-primary btn-block" href="login.html" for="confirm_password" type="submit">Register</a>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="login.html">Login Page</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
